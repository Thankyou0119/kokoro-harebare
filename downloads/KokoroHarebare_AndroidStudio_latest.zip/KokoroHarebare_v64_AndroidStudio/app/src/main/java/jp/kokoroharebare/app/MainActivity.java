package jp.kokoroharebare.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.widget.FrameLayout;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.os.Environment;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.util.Base64;
import java.io.*;

public class MainActivity extends Activity {
 private WebView web; private ValueCallback<Uri[]> fileCallback; private Uri cameraUri; private static final int FILE_CHOOSER=200, REQ_NOTIF=100, TAKE_PHOTO=201, PICK_PHOTO=202;
 private void configureSystemBars(){
  Window w=getWindow();
  // 白い背景に白いシステムナビゲーションアイコンが埋もれないよう、濃色背景＋白アイコンにする。
  w.setNavigationBarColor(Color.rgb(38,55,70));
  w.setStatusBarColor(Color.rgb(38,55,70));
  if(android.os.Build.VERSION.SDK_INT>=26){
   int flags=w.getDecorView().getSystemUiVisibility();
   flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
   flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
   w.getDecorView().setSystemUiVisibility(flags);
  }
  if(android.os.Build.VERSION.SDK_INT>=29){
   w.setNavigationBarContrastEnforced(false);
   w.setStatusBarContrastEnforced(false);
  }
 }
 @Override public void onCreate(Bundle state){super.onCreate(state);configureSystemBars();FrameLayout frame=new FrameLayout(this);web=new WebView(this);frame.setBackgroundColor(Color.rgb(38,55,70));frame.setPadding(0,0,0,0);frame.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(frame);frame.setOnApplyWindowInsetsListener((v,insets)->{int top,bottom;if(android.os.Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());top=bars.top;bottom=bars.bottom;}else{top=insets.getSystemWindowInsetTop();bottom=insets.getSystemWindowInsetBottom();}v.setPadding(0,top,0,bottom);if(android.os.Build.VERSION.SDK_INT>=30)return WindowInsets.CONSUMED;return insets.consumeSystemWindowInsets();});frame.requestApplyInsets();WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);web.addJavascriptInterface(new Bridge(),"AndroidBridge");web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView view,String url){if(url.startsWith("mailto:")||url.startsWith("https://line.me/")||url.startsWith("intent:")){try{startActivity(Intent.parseUri(url,Intent.URI_INTENT_SCHEME));}catch(Exception e){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}}return true;}return false;}});web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;try{startActivityForResult(p.createIntent(),FILE_CHOOSER);return true;}catch(Exception e){fileCallback=null;cb.onReceiveValue(null);return false;}}});web.loadUrl("file:///android_asset/index.html");if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);ReminderReceiver.schedule(this);}
 private void launchEmailAttachmentChooser(Intent shareIntent,String title){
  try {
   java.util.List<android.content.pm.ResolveInfo> mailApps=getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:")),PackageManager.MATCH_DEFAULT_ONLY);
   java.util.ArrayList<Intent> emailTargets=new java.util.ArrayList<>();
   java.util.HashSet<String> seen=new java.util.HashSet<>();
   for(android.content.pm.ResolveInfo info:mailApps){
    if(info.activityInfo==null||info.activityInfo.packageName==null||!seen.add(info.activityInfo.packageName))continue;
    Intent target=new Intent(shareIntent);target.setPackage(info.activityInfo.packageName);emailTargets.add(target);
   }
   if(emailTargets.isEmpty()){startActivity(Intent.createChooser(shareIntent,title));return;}
   Intent primary=emailTargets.remove(0);
   Intent chooser=Intent.createChooser(primary,title);
   if(!emailTargets.isEmpty())chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS,emailTargets.toArray(new Intent[0]));
   startActivity(chooser);
  }catch(Exception e){startActivity(Intent.createChooser(shareIntent,title));}
 }
 public class Bridge {
  @JavascriptInterface public void markSubmitted(String date){getSharedPreferences("kokoro_harebare",MODE_PRIVATE).edit().putString("submitted_date",date).apply();}
  @JavascriptInterface public void takePhoto(){runOnUiThread(()->{try{Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,"KokoroHarebare_"+System.currentTimeMillis()+".jpg");values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");if(android.os.Build.VERSION.SDK_INT>=29)values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/KokoroHarebare");cameraUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(cameraUri==null){web.evaluateJavascript("showToast('写真の保存先を作成できませんでした。',true)",null);return;}i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);i.setClipData(ClipData.newUri(getContentResolver(),"撮影画像",cameraUri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivityForResult(i,TAKE_PHOTO);}catch(Exception e){if(cameraUri!=null){try{getContentResolver().delete(cameraUri,null,null);}catch(Exception ignored){}cameraUri=null;}web.evaluateJavascript("showToast('カメラを起動できませんでした。端末の設定を確認してください。',true)",null);}});}
  @JavascriptInterface public void pickPhoto(){runOnUiThread(()->{try{Intent i=new Intent("android.intent.action.PICK",MediaStore.Images.Media.EXTERNAL_CONTENT_URI);i.setType("image/*");try{startActivityForResult(i,PICK_PHOTO);}catch(Exception first){Intent fallback=new Intent(Intent.ACTION_GET_CONTENT);fallback.setType("image/*");fallback.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(fallback,"写真を選択"),PICK_PHOTO);}}catch(Exception e){web.evaluateJavascript("document.getElementById('photoInput').click()",null);}});}
  @JavascriptInterface public void sharePhotos(String json,String channel,String subject,String body){runOnUiThread(()->{try{org.json.JSONArray arr=new org.json.JSONArray(json);java.util.ArrayList<Uri> uris=new java.util.ArrayList<>();for(int n=0;n<arr.length();n++){org.json.JSONObject item=arr.getJSONObject(n);String data=item.getString("data");int comma=data.indexOf(',');if(comma<0)continue;byte[] bytes=Base64.decode(data.substring(comma+1),Base64.DEFAULT);ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,item.optString("name","KokoroHarebare_photo_"+(n+1)+".jpg").replaceAll("[^\\p{L}\\p{N}._-]","_"));cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");if(android.os.Build.VERSION.SDK_INT>=29)cv.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/KokoroHarebare");Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);if(u==null)continue;try(OutputStream os=getContentResolver().openOutputStream(u)){if(os==null)throw new IOException("open output failed");os.write(bytes);}uris.add(u);}if(uris.isEmpty()){web.evaluateJavascript("showToast('共有できる写真を準備できませんでした。',true)",null);return;}Intent i;if(uris.size()==1){i=new Intent(Intent.ACTION_SEND);i.putExtra(Intent.EXTRA_STREAM,uris.get(0));}else{i=new Intent(Intent.ACTION_SEND_MULTIPLE);i.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);}i.setType("image/*");i.putExtra(Intent.EXTRA_SUBJECT,subject);i.putExtra(Intent.EXTRA_TEXT,body);if(uris.size()>1)i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);ClipData clip=ClipData.newUri(getContentResolver(),"共有する写真",uris.get(0));for(int ci=1;ci<uris.size();ci++)clip.addItem(new ClipData.Item(uris.get(ci)));i.setClipData(clip);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);if("line".equals(channel)){i.setPackage("jp.naver.line.android");try{startActivity(i);return;}catch(Exception ignored){i.setPackage(null);}}if("email".equals(channel))launchEmailAttachmentChooser(i,"メールアプリを選択");else startActivity(Intent.createChooser(i,"写真の共有先を選択"));}catch(Exception e){web.evaluateJavascript("showToast('写真をまとめて共有できませんでした。写真を保存してから再度お試しください。',true)",null);}});}
  @JavascriptInterface public void shareText(String subject,String body,String channel){runOnUiThread(()->{try{if("line".equals(channel)){Intent line=new Intent(Intent.ACTION_SEND);line.setType("text/plain");line.putExtra(Intent.EXTRA_SUBJECT,subject);line.putExtra(Intent.EXTRA_TEXT,body);line.setPackage("jp.naver.line.android");try{startActivity(line);return;}catch(Exception ignored){line.setPackage(null);startActivity(Intent.createChooser(line,"LINEなどの共有先を選択"));return;}}Intent email=new Intent(Intent.ACTION_SENDTO);email.setData(Uri.parse("mailto:"));email.putExtra(Intent.EXTRA_SUBJECT,subject);email.putExtra(Intent.EXTRA_TEXT,body);try{startActivity(email);}catch(Exception noMailApp){Intent fallback=new Intent(Intent.ACTION_SEND);fallback.setType("text/plain");fallback.putExtra(Intent.EXTRA_SUBJECT,subject);fallback.putExtra(Intent.EXTRA_TEXT,body);startActivity(Intent.createChooser(fallback,"メールなどの送信先を選択"));}}catch(Exception e){web.evaluateJavascript("showToast('共有アプリを開けませんでした。メールアプリやLINEが利用できるか確認してください。',true)",null);}});}
  @JavascriptInterface public void shareFile(String name,String mime,String base64,String channel,String subject,String body){runOnUiThread(()->{try{byte[] data=Base64.decode(base64,Base64.DEFAULT);String safeName=name.replaceAll("[^\\p{L}\\p{N}._-]","_");String normalizedMime=(mime==null?"application/octet-stream":mime.split(";",2)[0].trim()).toLowerCase(java.util.Locale.ROOT);if(normalizedMime.isEmpty())normalizedMime="application/octet-stream";String lowerName=safeName.toLowerCase(java.util.Locale.ROOT);if(lowerName.endsWith(".csv"))normalizedMime="text/csv";else if(lowerName.endsWith(".pdf"))normalizedMime="application/pdf";else if(lowerName.endsWith(".jpg")||lowerName.endsWith(".jpeg"))normalizedMime="image/jpeg";File dir=new File(getCacheDir(),"shared");if(!dir.exists()&&!dir.mkdirs())throw new IOException("cannot create share cache");File f=new File(dir,safeName);try(FileOutputStream o=new FileOutputStream(f)){o.write(data);}if(android.os.Build.VERSION.SDK_INT>=29){try{ContentValues cv=new ContentValues();cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,safeName);cv.put(android.provider.MediaStore.Downloads.MIME_TYPE,normalizedMime);cv.put(android.provider.MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/KokoroHarebare");Uri saved=getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);if(saved!=null){try(OutputStream os=getContentResolver().openOutputStream(saved)){if(os!=null)os.write(data);}}}catch(Exception ignored){/* cache-backed share URI remains usable if the public download copy fails */}}Uri uri=new Uri.Builder().scheme("content").authority(getPackageName()+".share").appendPath("shared").appendPath(safeName).build();Intent i=new Intent(Intent.ACTION_SEND);i.setType(normalizedMime);i.putExtra(Intent.EXTRA_STREAM,uri);i.putExtra(Intent.EXTRA_SUBJECT,subject);i.putExtra(Intent.EXTRA_TEXT,body);i.setClipData(ClipData.newUri(getContentResolver(),safeName,uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);if("line".equals(channel)){i.setPackage("jp.naver.line.android");try{startActivity(i);return;}catch(Exception ignored){i.setPackage(null);}}if("email".equals(channel))launchEmailAttachmentChooser(i,"メールアプリを選択");else startActivity(Intent.createChooser(i,"添付ファイルの送信先を選択"));}catch(Exception e){web.evaluateJavascript("showToast('ファイルを共有できませんでした。もう一度お試しください。',true)",null);}});}
 }
 // v64: カメラ等のJPEGはEXIFの向き情報だけを持つことが多い。デコード後に画素を回転して、プレビュー・記録・共有で正しい向きにする。
 private Bitmap rotateByExif(byte[] bytes,Bitmap src){
  try(InputStream is=new ByteArrayInputStream(bytes)){
   android.media.ExifInterface exif=new android.media.ExifInterface(is);
   int o=exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,android.media.ExifInterface.ORIENTATION_NORMAL);
   android.graphics.Matrix m=new android.graphics.Matrix();
   switch(o){
    case android.media.ExifInterface.ORIENTATION_ROTATE_90: m.postRotate(90); break;
    case android.media.ExifInterface.ORIENTATION_ROTATE_180: m.postRotate(180); break;
    case android.media.ExifInterface.ORIENTATION_ROTATE_270: m.postRotate(270); break;
    case android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL: m.postScale(-1,1); break;
    case android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL: m.postScale(1,-1); break;
    case android.media.ExifInterface.ORIENTATION_TRANSPOSE: m.postRotate(90); m.postScale(-1,1); break;
    case android.media.ExifInterface.ORIENTATION_TRANSVERSE: m.postRotate(270); m.postScale(-1,1); break;
    default: return src;
   }
   Bitmap r=Bitmap.createBitmap(src,0,0,src.getWidth(),src.getHeight(),m,true);
   if(r!=src)src.recycle();
   return r;
  }catch(Exception|OutOfMemoryError e){return src;}
 }
 @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==FILE_CHOOSER&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res,data));fileCallback=null;}else if(req==PICK_PHOTO&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();try(InputStream in=getContentResolver().openInputStream(u);ByteArrayOutputStream raw=new ByteArrayOutputStream()){if(in==null)throw new IOException("選択した写真を開けません");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)raw.write(buf,0,n);Bitmap original=BitmapFactory.decodeByteArray(raw.toByteArray(),0,raw.size());if(original==null)throw new IOException("選択した写真を読み込めません");original=rotateByExif(raw.toByteArray(),original);float scale=Math.min(1f,1400f/Math.max(original.getWidth(),original.getHeight()));Bitmap preview=scale<1f?Bitmap.createScaledBitmap(original,Math.max(1,(int)(original.getWidth()*scale)),Math.max(1,(int)(original.getHeight()*scale)),true):original;ByteArrayOutputStream compressed=new ByteArrayOutputStream();preview.compress(Bitmap.CompressFormat.JPEG,78,compressed);if(preview!=original)preview.recycle();original.recycle();String encoded=Base64.encodeToString(compressed.toByteArray(),Base64.NO_WRAP);web.evaluateJavascript("(function(){const p=document.getElementById('photoPreview');if(!p)return;p.src='data:image/jpeg;base64,"+encoded+"';p.style.display='block';document.getElementById('photoPreviewWrap').classList.remove('hidden');if(typeof saveDraft==='function')saveDraft()})()",null);}catch(Exception e){web.evaluateJavascript("showToast('選択した写真を読み込めませんでした。別の写真を選んでください。',true)",null);}}else if(req==TAKE_PHOTO){if(res==RESULT_OK&&cameraUri!=null){try(InputStream in=getContentResolver().openInputStream(cameraUri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new IOException("撮影画像を読み込めません");byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);Bitmap original=BitmapFactory.decodeByteArray(out.toByteArray(),0,out.size());if(original==null)throw new IOException("撮影画像の形式を読み込めません");original=rotateByExif(out.toByteArray(),original);float scale=Math.min(1f,1600f/Math.max(original.getWidth(),original.getHeight()));Bitmap preview=scale<1f?Bitmap.createScaledBitmap(original,Math.max(1,(int)(original.getWidth()*scale)),Math.max(1,(int)(original.getHeight()*scale)),true):original;ByteArrayOutputStream compressed=new ByteArrayOutputStream();preview.compress(Bitmap.CompressFormat.JPEG,82,compressed);if(preview!=original)preview.recycle();original.recycle();String encoded=Base64.encodeToString(compressed.toByteArray(),Base64.NO_WRAP);web.evaluateJavascript("(function(){const p=document.getElementById('photoPreview');if(!p)return;p.src='data:image/jpeg;base64,"+encoded+"';p.style.display='block';document.getElementById('photoPreviewWrap').classList.remove('hidden');if(typeof saveDraft==='function')saveDraft()})()",null);}catch(Exception e){web.evaluateJavascript("showToast('撮影した写真を読み込めませんでした。もう一度撮影してください。',true)",null);}}else if(cameraUri!=null){try{getContentResolver().delete(cameraUri,null,null);}catch(Exception ignored){}}cameraUri=null;}}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
